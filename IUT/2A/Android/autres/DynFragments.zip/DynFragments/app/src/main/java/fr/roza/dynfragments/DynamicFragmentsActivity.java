package fr.roza.dynfragments;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentTransaction;
import fr.roza.dynfragments.R;

public class DynamicFragmentsActivity extends Activity
{
    private Fragment fragment1;
    private Fragment fragment2;
    private Fragment currentfragment;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

	fragment1 = new fr.roza.dynfragments.Fragment1();
	fragment2 = new fr.roza.dynfragments.Fragment2();

	currentfragment = fragment1;

	// si l'activity démarre pour la 1ere fois...
	if( savedInstanceState == null ) {
	    getFragmentManager()
		.beginTransaction()
		.add( R.id.framelayout, currentfragment )
		.commit();
	}
	// sinon ...
	else{
	    // si un fragment est dans la pile c'est que le fragment
	    // courant est le fragment 2.
	    if( getFragmentManager().getBackStackEntryCount() > 0 ) {
		currentfragment = fragment2;
	    }
	}
    }


    public void onClick(View view) {
	if( currentfragment == fragment1 ) {
	    currentfragment = fragment2;
	    FragmentTransaction frtr = getFragmentManager().beginTransaction();
	    frtr.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN );
	    frtr.replace( R.id.framelayout, currentfragment );
	    frtr.addToBackStack(null);
	    frtr.commit();
	}
	else {
	    currentfragment = fragment1;
	    getFragmentManager().popBackStack();
	}

    }
    
}
