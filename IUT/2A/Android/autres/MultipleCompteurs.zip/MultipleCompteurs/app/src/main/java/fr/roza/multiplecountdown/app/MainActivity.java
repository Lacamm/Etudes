package fr.roza.multiplecountdown.app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView lvItems;
    private List<Product> lstProducts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvItems = (ListView) findViewById(R.id.lvItems);
        lstProducts = new ArrayList<Product>();
        lstProducts.add(new Product("A", System.currentTimeMillis() + 10000));
        lstProducts.add(new Product("B", System.currentTimeMillis() + 20000));
        lstProducts.add(new Product("C", System.currentTimeMillis() + 20000));
        lstProducts.add(new Product("D", System.currentTimeMillis() + 20000));
        lstProducts.add(new Product("E", System.currentTimeMillis() + 20000));
        lstProducts.add(new Product("F", System.currentTimeMillis() + 20000));
        lstProducts.add(new Product("G", System.currentTimeMillis() + 30000));
        lstProducts.add(new Product("H", System.currentTimeMillis() + 20000));
        lstProducts.add(new Product("I", System.currentTimeMillis() + 20000));
        lstProducts.add(new Product("J", System.currentTimeMillis() + 40000));
        lstProducts.add(new Product("K", System.currentTimeMillis() + 20000));
        lstProducts.add(new Product("L", System.currentTimeMillis() + 50000));
        lstProducts.add(new Product("M", System.currentTimeMillis() + 60000));
        lstProducts.add(new Product("N", System.currentTimeMillis() + 20000));
        lstProducts.add(new Product("O", System.currentTimeMillis() + 10000));

        lvItems.setAdapter(new CountdownAdapter(MainActivity.this, lstProducts));
    }



}
