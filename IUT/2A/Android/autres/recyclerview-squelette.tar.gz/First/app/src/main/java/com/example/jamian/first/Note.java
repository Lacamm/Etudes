package com.example.jamian.first;

/**
 * Created by jamian on 21/11/16.
 */
public class Note {
    public Note(String titre,String contenu)
    {
        //TODO
    }

    public String getTitre() {
        // TODO
        return "";
    }
    public String getContenu() {
        // TODO
        return "";
    }


}
