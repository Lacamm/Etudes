package com.example.jamian.first;

import java.util.ArrayList;

/**
 * Created by jamian on 21/11/16.
 */
public class ListeNotes {

    public ListeNotes()
    {
        ajouteNote("Note 1","Contenu de la note 1");
        ajouteNote("Autre note","Et un autre contenu");
        ajouteNote("Petite troisième","On va faire un contenu un peu plus long, pour voir comment ça passe sur tous les affichages. Hopla ! Et même encore un peu plus long histoire de dire. Après tout, normalement on a tout un écran pour l'afficher, donc on est bien large...");

    }

    public void ajouteNote(String titre,String contenu)
    {
        //TODO
    }

    public Note get(int i) {
        return null;
        //TODO
    }

    public boolean deleteNote(int i) {
        return true;
        // TODO
    }

    public int deleteNote(String titre) {
        return -1;
        // TODO
    }

    public int size() {
        return -1;
        //TODO
    }
}
