package fr.roza.multiplecountdown.app;

/**
 * Created by roza on 10/03/2016.
 */
public class Product {
    String name;
    long expirationTime;

    public Product(String name, long expirationTime) {
        this.name = name;
        this.expirationTime = expirationTime;
    }
}
