Dans un terminal

rmiregistry&
java Server

Dans un autre terminal
java Client
