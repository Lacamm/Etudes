window.onload=function()
{

	// Tableau des pays
	tableauPays=new Array();
	
	tableauPays[1]='Azerbaïdjan';
	tableauPays[2]='Turkménistan';
	tableauPays[3]='Ouzbékistan';
	tableauPays[4]='Afghanistan';
	tableauPays[5]='Pakistan';
	tableauPays[6]='Tadjikistan';
	tableauPays[7]='Kirghizistan';
	alert('window on load');
	// Ecriture du titre
	document.getElementById("titre").innerHTML="<p>Jeu des pays</p>";
	
	var s="";
	for (let i=1;i<=7;i++)
	{
		s="<span id=\"numero"+i+"\""+">"+i+"</span>"+"\n";
		s+="<select name=\"liste"+i+"\""+">"+"\n";
		
		s+="<option value=\"\""+">Choisir.."+"</option>"+"\n";
		for (let j=1;j<=7;j++)
		{
			s+="<option value=\""+tableauPays[j]+"\">"+tableauPays[j]+"</option>"+"\n";
		}
		s+="</select>"+"<br>";
		//alert(s);
		document.getElementById("listes").innerHTML+=s;
	}
	
	
}



// fonction Valider
function fonctionValider()
{	
	
	
}

function fonctionReinitialiser()
{	
	for (let i=1;i<=7;i++)
	{
	document.forms["listes"].elements["liste"+i].selectedIndex=0;
	document.getElementById("numero"+i).style.backgroundColor='#FFFFFF';
	}
		
}


