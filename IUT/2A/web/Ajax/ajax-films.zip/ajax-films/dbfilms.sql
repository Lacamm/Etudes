-- MySQL dump 10.14  Distrib 5.5.52-MariaDB, for osx10.12 (x86_64)
--
-- Host: localhost    Database: DBscott
-- ------------------------------------------------------
-- Server version	10.0.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `DBscott`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `DBscott` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `DBscott`;

--
-- Table structure for table `FILM`
--

DROP TABLE IF EXISTS `FILM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FILM` (
  `id_film` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(50) NOT NULL,
  `annee` int(11) NOT NULL,
  `genre` varchar(50) DEFAULT NULL,
  `resume` varchar(100) DEFAULT NULL,
  `code_pays` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id_film`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FILM`
--

LOCK TABLES `FILM` WRITE;
/*!40000 ALTER TABLE `FILM` DISABLE KEYS */;
INSERT INTO `FILM` VALUES (1,'CENDRILLON',1950,'Dessin Anim','Conte de f','FR'),(2,'LES ARISTOCHATS',1955,'Deesin Anim','un dessin anim','BE'),(3,'LA BELLE AUX BOIS DORMANT',1960,'Dessin Anim','Conte de f','LU'),(4,'BLANCHE NEIGE',1965,'Dessin Anim','Conte de f','UK'),(5,'ATLANTIS',2001,'Dessin Anim','Dernier Waltt Disney. Une r','NL'),(6,'SHREK',1975,'Dessin Anim','L\'ogre .... A-t-il  un coeur ?','US'),(7,'ALADIN',1980,'Dessin Anim','Au pays des r','D'),(8,'LES TROIS PETITS COCHONS',1985,'Dessin Anim','Un classique bien connu des plus jeunes mais ','FR'),(9,'VAMPIRES',1990,'Fantastique','Entre l\'horreur et l\'humour. ','BE'),(10,'BLADE',1995,'Fantastique',' ','LU'),(11,'MATRIX',2000,'R','Au coeur de la r','UK'),(12,'LE BON,LA BRUTE ET LE TRUANT',1996,'western','Vieux western de nos grands parents. ','NL'),(13,'LES MYSTERES DE L OUEST',1998,'western',' ','US'),(14,'LE DINER DE CON',1999,'Comedie',' ','D'),(15,'LE PERE NOEL EST UNE ORDURE',1982,'Humour','Pleins d\'humour avec les meilleurs comiques','FR');
/*!40000 ALTER TABLE `FILM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALISATEUR`
--

DROP TABLE IF EXISTS `REALISATEUR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REALISATEUR` (
  `id_realis` int(11) NOT NULL AUTO_INCREMENT,
  `nom_realis` varchar(30) DEFAULT NULL,
  `prenom_realis` varchar(30) DEFAULT NULL,
  `anne_nais` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_realis`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALISATEUR`
--

LOCK TABLES `REALISATEUR` WRITE;
/*!40000 ALTER TABLE `REALISATEUR` DISABLE KEYS */;
INSERT INTO `REALISATEUR` VALUES (1,'Besson','Luc',1940),(2,'Bilier','Bernard',1945),(3,'Columbus','Chris',1980),(4,'Allen','Woody',1970),(5,'Chirac','Jacques',1949),(6,'Aaaron','Paul',1952),(7,'Adler','Carinne',1965),(8,'Cameron','James',1971),(9,'Campan','Bernard',1942),(10,'Cammel','Donald',1964),(11,'Hugues','John',1955),(12,'Haward','Ron',1954),(13,'Hooks','Kevin',1967);
/*!40000 ALTER TABLE `REALISATEUR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALISE`
--

DROP TABLE IF EXISTS `REALISE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REALISE` (
  `id_film` int(11) NOT NULL,
  `id_realis` int(11) NOT NULL,
  PRIMARY KEY (`id_film`,`id_realis`),
  KEY `id_realis` (`id_realis`),
  CONSTRAINT `realise_ibfk_1` FOREIGN KEY (`id_film`) REFERENCES `FILM` (`id_film`),
  CONSTRAINT `realise_ibfk_2` FOREIGN KEY (`id_realis`) REFERENCES `REALISATEUR` (`id_realis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALISE`
--

LOCK TABLES `REALISE` WRITE;
/*!40000 ALTER TABLE `REALISE` DISABLE KEYS */;
INSERT INTO `REALISE` VALUES (1,2),(2,1),(3,3),(4,3),(5,4),(6,5),(7,6),(8,7),(9,8),(10,9),(11,10),(12,11),(13,12),(14,13),(15,13);
/*!40000 ALTER TABLE `REALISE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `utilisateur` (
  `login` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateur`
--

LOCK TABLES `utilisateur` WRITE;
/*!40000 ALTER TABLE `utilisateur` DISABLE KEYS */;
INSERT INTO `utilisateur` VALUES ('gege','pass'),('gege','pass');
/*!40000 ALTER TABLE `utilisateur` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-25 16:20:38
