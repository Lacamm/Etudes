<?php
include("connexion.php");

$annee=$_POST['annee'];
if (!empty($annee)){
	$connexion = connect_bd();
	$sql="SELECT * FROM FILM WHERE annee=:annee ORDER BY titre";
  	$stmt=$connexion->prepare($sql);
    $stmt->bindParam(':annee', $annee, PDO::PARAM_INT);
    $stmt->execute();
	echo "Film : <select name='film'>";

	while ($row= $stmt->fetch(PDO::FETCH_OBJ))
		echo "<option value='".$row->id_film."'>".$row->titre."</option>";
	echo "</select>";
	}
?>