<html>
<head>
<title>Affichage AJAX</title>
<script>
function ajax(strURL){
var self = this;
// Mozilla/Safari
if (window.XMLHttpRequest) {
	self.xmlHttpReq = new XMLHttpRequest();
}
// IE
else if (window.ActiveXObject) {
	self.xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
}
self.xmlHttpReq.open('POST', strURL, true);
self.xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
self.xmlHttpReq.onreadystatechange = function() {
	if (self.xmlHttpReq.readyState == 4) {
		affichage(self.xmlHttpReq.responseText);
	}
}
self.xmlHttpReq.send(envoiPost());
}

function envoiPost(){
    var form = document.forms['form'];
    var annee = form.annee.value;
    post="annee=" + annee;
    return post
}
function affichage(reponse){
    console.log(reponse);
    document.getElementById("affiche").innerHTML = reponse;
}
</script>

</head>

<body>
<center>
<form action="index.php">
<input type="submit" value="Accueil">
</form>
<fieldset>
<legend>AJAX</legend>
<form action="" name="form">
<?php
include("connexion.php");
$connexion = connect_bd();
if (empty($connexion)){
	echo "Problème de connexion";
}
else
    {
		$films=Array();
  		$sql="SELECT * FROM FILM ORDER BY annee";
  		echo "Année : <select name='annee' size='1' onChange='JavaScript:ajax(\"ajax2.php\")'>";
  		foreach ($connexion->query($sql) as $row)
			echo "<option value='".$row["annee"]."'>".$row["annee"]."</option>";
		echo "</select>";
	}
?>

<div id="affiche"></div><br>
</form>
</fieldset>
</center>
</body>
</html>