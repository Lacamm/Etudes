<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Affichage AJAX</title>
<style> 
    article
    {
        width: 60%;
        margin: auto;
        text-align: center;
    } 

    #affiche{margin-top: 20px;}
</style>

</head>

<body>
<article>
<fieldset>
<legend>AJAX</legend>
<form action="#">
<?php
include("connexion.php");
$connexion = connect_bd();
if (empty($connexion))
	echo "Problème de connexion";
else
    {
		$films=Array();
  		$sql="SELECT * FROM FILM ORDER BY annee";
  		echo "Année <select name='annee' size='1' onChange='JavaScript:ajax(\"ajax2.php\")'>";
  		foreach ($connexion->query($sql) as $row)
		  echo "<option value='".$row["annee"]."'>".$row["annee"]."</option>";
		echo "</select>";
	}
?>

<div id="affiche"></div><br>
</form>
</fieldset>
</article>
</body>
</html>
<script>
function ajax(strURL){
    var self = this;
    // Mozilla/Safari
    if (window.XMLHttpRequest) {
        self.xmlHttpReq = new XMLHttpRequest();
    }
    // IE
    else if (window.ActiveXObject) {
        self.xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
    }
    self.xmlHttpReq.open('POST', strURL, true);
    self.xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    self.xmlHttpReq.onreadystatechange = function() {
        if (self.xmlHttpReq.readyState == 4) {
            affichage(self.xmlHttpReq.responseText);
        }
    }
    self.xmlHttpReq.send("annee=" + getAnnee());
    }

function getAnnee(){
    return document.forms[0].annee.value;
}

function affichage(reponse){
    document.getElementById("affiche").innerHTML = reponse;
}

</script>


