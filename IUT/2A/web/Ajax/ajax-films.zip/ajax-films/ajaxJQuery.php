<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Affichage AJAX</title>
<style> 
  article
    {
        width: 60%;
        margin: auto;
        text-align: center;
    } 

  #affiche{margin-top: 20px;}
</style>
<script src="js/jquery.min.js"></script>
</head>

<body>
<article>
<fieldset>
<legend>AJAX</legend>
<form action="#">
<?php
include("connexion.php");
$connexion = connect_bd();
if (empty($connexion)){
	  echo "Problème de connexion";
 }
else
 {
		  $films=Array();
  		$sql="SELECT * FROM FILM ORDER BY annee";
  		echo 'Année : <select name="annee" size="1" onChange="JavaScript:ajax()">';
  		foreach ($connexion->query($sql) as $row)
			  echo "<option value='".$row["annee"]."'>".$row["annee"]."</option>";
		  echo "</select>";
	}
?>

<div id="affiche"></div><br>
</form>
</fieldset>
</article>
</body>
</html>
<script>
function ajax()
{
  $.ajax({
          url: "http://localhost/~roza/ex3/ajax2.php",
          type: "POST",
          dataType: "text",
          data:"annee=" + $('select[name=annee]').val(),
          success: function(reponse) { 
              affichage(reponse);
                  },
          error: function(req, status, err) {
                  console.log('Problème ajax: '+ err)
                  }
          });
}

function getAnnee(){
    return document.forms[0].annee.value;
}

function affichage(reponse)
{
    console.log(reponse);
    $('#affiche').html(reponse);
}
</script>
