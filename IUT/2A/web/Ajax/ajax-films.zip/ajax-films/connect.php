<?php
define('USER',"scott");
define('PASSWD',"tiger");
define('SERVER',"localhost");
define('BASE',"DBscott");
?>

