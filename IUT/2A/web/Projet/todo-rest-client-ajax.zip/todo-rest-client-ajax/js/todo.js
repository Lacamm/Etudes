$(function() {

    $("#button").click(refreshTaskList);

    function refreshTaskList(){
        $("#currenttask").empty();
        $.ajax({
            url: "http://localhost:3000/tasks",
            type: "GET",
            dataType : "json",
            success: function(tasks) {
                console.log(JSON.stringify(tasks));
                $('#taches').empty();
                $('#taches').append($('<ul>'));
                for(let i=0;i<tasks.length;i++){
                    $('#taches ul')
                    .append($('<li>')
                    .append($('<a>')
                        .text(tasks[i].title)
                        ).on("click", tasks[i], details)
                    );
                        }
                    },
            error: function(req, status, err) {
                        $("#taches").html("<b>Impossible de récupérer les taches à réaliser !</b>");
                        }
                        });
        }

    function details(event){
        $("#currenttask").empty();
        formTask(false);
        fillFormTask(event.data);
        }

    // Objet Task en JS
    class Task{
        constructor(title, description, done, uri){
            this.title = title;
            this.description = description;
            this.done = done;
            this.uri = uri;
        }
    }
    
    $("#tools #add").on("click", formTask);
    $('#tools #del').on('click', delTask);

    function formTask(isnew){
        $("#currenttask").empty();
        $("#currenttask")
            .append($('<span>Titre<input type="text" id="titre"><br></span>'))
            .append($('<span>Description<input type="text" id="descr"><br></span>'))
            .append($('<span>Done<input type="checkbox" id="done"><br></span>'))
            .append($('<span><input type="hidden" id="turi"><br></span>'))
            .append(isnew?$('<span><input type="button" value="Save Task"><br></span>').on("click", saveNewTask)
                         :$('<span><input type="button" value="Modify Task"><br></span>').on("click", saveModifiedTask)
                );
        }

    function fillFormTask(t){
        $("#currenttask #titre").val(t.title);
        $("#currenttask #descr").val(t.description);
         t.uri=(t.uri == undefined)?"http://localhost:3000/tasks/"+t.id:t.uri;
         $("#currenttask #turi").val(t.uri);
        t.done?$("#currenttask #done").prop('checked', true):
        $("#currenttask #done").prop('checked', false);
    }
    function saveNewTask(){
        const task = new Task(
            $("#currenttask #titre").val(),
            $("#currenttask #descr").val(),
            $("#currenttask #done").is(':checked')
            );
        console.log(JSON.stringify(task));
        $.ajax({
            url: "http://localhost:3000/tasks",
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(task),
            dataType: 'json',
            success: function (msg) {
                alert('Save Success');
                refreshTaskList();
            },
            error: function (err){
                alert('Save Error');
            }
            });
       
    }

    function saveModifiedTask(){
        const task = new Task(
            $("#currenttask #titre").val(),
            $("#currenttask #descr").val(),
            $("#currenttask #done").is(':checked'),
            $("#currenttask #turi").val()
            );
        $.ajax({
            url: task.uri,
            type: 'PUT',
            contentType: "application/json",
            data: JSON.stringify(task),
            dataType: 'json',
            success: function (res) {
                console.log("Résultat du PUT:"+res);
                refreshTaskList();
            },
            error: function (err){
                alert('Update Error');
            }
            });   
    }

    function delTask(){
        if ($("#currenttask #turi").val()){
        $.ajax({
            url: $("#currenttask #turi").val(),
            type: 'DELETE',
            dataType: 'json',
            success: function (msg) {
                alert('DELETE Success');
                refreshTaskList();
            },
            error: function (err){
                alert('DELETE Error: ' + err);
            }
            });
        }
    }

});
