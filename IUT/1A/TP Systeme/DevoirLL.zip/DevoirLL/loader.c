#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "types.h"


int loader(int debut, module mod, casemem *mem) {

  return debut;
}
