#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "types.h"

module linker(int nbmods, module *mods) {
  int nbinstr = 0;
  int memsize = 0;
  int nbsymb = 0;
  
  //passe 1, créer un module unique pour les regrouper tous en décalant les adresses relatives dans chaque module

  casemem *linstr = (casemem *)malloc(nbinstr * sizeof(casemem));

  casemem *mem = (casemem *)malloc(memsize * sizeof(casemem));
 
  
  module mod = newmod(nbinstr,linstr,memsize,mem);
  
   
  //passe 2, remplir la table des symboles
  
  
  //passe 3, remplacer pour chaque référence le nom par l'adresse de la définition

  
  return mod;
}
