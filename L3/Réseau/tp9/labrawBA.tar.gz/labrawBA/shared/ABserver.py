#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
from ABproto import *
from time import sleep


async def rcvsnd(s):
    """Reçoit un paquet AB et applique le protocole."""
    dump, addr = await s.ABreceivefrom()
    p = ABpacket.fromstr(dump)
    print("\r\n" + 30 * "*" + ("\nPaquet reçu de: %s\n" % addr[0]))
    p.affiche()  # demander un affichage complet avec p.affiche(full=True)
    sleep(0.1)


async def main():
    s = ABsocket()
    await s.create_ABsocket()
    # s.bufsize()  #Décommenter si on souhaite afficher les tailles des buffers
    while True:
        await rcvsnd(s)
    s.close()


if __name__ == "__main__":
    asyncio.run(main())
