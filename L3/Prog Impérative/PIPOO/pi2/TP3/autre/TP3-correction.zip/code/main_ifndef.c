#include "catalan.h"
#include "pascal.h"

int main() {

    printf("%ld\n",catalan(6));
    pascal(6);
    return EXIT_SUCCESS;
}
