#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <assert.h>

#define TAILLE 5

bool est_trie(int tableau[], int taille);
bool doublons(int tableau[], int taille);

/* Correction laissée en exercice */
int dichotomie(int tableau[], int taille);

int main() {
    int un_tableau_non_trie[TAILLE] = { 4, 8, 5, 2, 1 };
    int un_tableau_trie_sans_doublons[TAILLE] = { 2, 3, 4, 6, 8 };
    int un_tableau_trie_avec_doublons[TAILLE] = { 2, 3, 3, 6, 8 };

    printf("%d\n",doublons(un_tableau_trie_sans_doublons,TAILLE));
    printf("%d\n",doublons(un_tableau_trie_avec_doublons,TAILLE));
    puts(doublons(un_tableau_trie_sans_doublons,TAILLE) ? "true" : "false");
    puts(doublons(un_tableau_trie_avec_doublons,TAILLE) ? "true" : "false");

    return EXIT_SUCCESS;
}

/* Pour vérifier si un tableau est trié, il suffit de le parcourir 
 * et de s'assurer que chaque case i contient bien une valeur <= 
 * à la valeur contenue dans la case suivante
 */
bool est_trie(int* tableau, int taille) {
    for(int i = 0; i < taille-1; ++i) 
        if(tableau[i]>tableau[i+1])
            return false;
    return true;
}

/* Pour s'assurer qu'un tableau _trié_ ne contient pas de doublons, 
 * il suffit de comparer deux valeurs successives et de retourner faux 
 * lorsqu'on en rencontre deux identiques
 */
bool doublons(int* tableau, int taille) {
    /* L'assertion permet d'arrêter l'exécution du programme si la fonction 
     * doublons est appelée sur un tableau non trié : il s'agit d'une 
     * pré-condition, liée à la programmation par contrats
     */
    assert(est_trie(tableau,taille));
    for(int i = 0; i < taille-1; ++i) 
        if(tableau[i] == tableau[i+1])
            return true;
    return false;
}

/* Correction laissée en exercice */
int dichotomie(int tableau[], int taille) {
    assert(est_trie(tableau,taille));
    return 0;
}
