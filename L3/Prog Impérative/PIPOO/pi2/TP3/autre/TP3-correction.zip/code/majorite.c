#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define TAILLE 11

/* Algorithme de Boyer-Moore --- NON DEMANDE DANS CE TP, MAIS DANS LE SUIVANT */
int element_majoritaire(int* arr, int taille) { 
    int count = 0, majoritaire;
    for (int i = 0; i < taille; i++) {
        if (count == 0) {
            majoritaire = arr[i];
            count = 1;
        }
        else if (arr[i] == majoritaire) 
            count++;
        else
            count--;
    }
    count = 0;
    for (int i = 0; i < taille; i++)
        if (arr[i] == majoritaire)
            count++;
    if (count > taille/2)
        return majoritaire;
    return -1;
}

int main() {

    srand(time(NULL));
    int* v = malloc( TAILLE * sizeof(int) );

    for(int i = 0; i < TAILLE; i++) {
        v[i] = rand() % 3 + 1;
        printf("%d ", v[i]);
    }

    printf("\nElement majoritaire : %d", element_majoritaire(v,TAILLE));

    return 0;

}
