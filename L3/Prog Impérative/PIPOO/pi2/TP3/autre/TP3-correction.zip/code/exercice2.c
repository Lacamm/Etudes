/* NOTE --- la correction est donnée dans un unique fichier, mais il 
 * faudrait déclarer les fonctions dans un fichier en-tête (.h), les 
 * implémenter dans un fichier .c et placer la fonction principale dans 
 * un fichier à part, en créant un Makefile pour gérer la compilation. 
 * Cela peut être fait en exercice pour vous habituer à le faire
 */

#include <stdlib.h>
#include <stdio.h>

void modifier(int*);
void echanger(int*, int*);
void trier(int*, int*, int*);

int main() {
    int a,b,c;
    printf("Valeur à modifier : ");
    scanf("%d",&a);
    modifier(&a);
    printf("Valeur après modification : %d\n", a);

    printf("Valeurs à échanger : ");
    /* Comme la fonction printf, la fonction scanf peut lire plusieurs valeurs à la fois. 
     * Attention à ne pas intégrer de \n dans la chaîne de caractères (sinon la validation, 
     * avec la touche Entrée, pourrait ne pas fonctionner correctement)
     */
    scanf("%d %d", &a,&b);
    printf("Valeurs avant échange : %d %d\n", a,b);
    echanger(&a,&b);
    printf("Valeurs après échange : %d %d\n", a,b);

    printf("Valeurs à trier : ");
    scanf("%d %d %d", &a,&b,&c);
    printf("Valeurs avant tri : %d %d %d\n", a,b,c);
    trier(&a,&b,&c);
    printf("Valeurs après tri : %d %d %d", a,b,c);

    return EXIT_SUCCESS;
}

/* Rappel : la variable a est un pointeur, elle contient donc une _adresse mémoire_ 
 * En la déréférençant (utilisation de *a), on accède à la case mémoire pointée, 
 * contenant un entier
 */
void modifier(int *a) {
    (*a) = (*a)i*(*a);
}

/* Cf transparents du CM#3 sur CELENE */
void echanger(int *a, int *b) {
    int c = *a;
    *a = *b;
    *b = c;
}

/* Manière optimale de trier trois entiers, représentés par leurs 
 * adresses en mémoire. Après les deux premiers if, on a la certitude 
 * que c est plus grand que a _et_ b. Il suffit donc de comparer 
 * à nouveau ces deux valeurs pour trier les entiers. 
 * On notera l'appel à la fonction echanger sur les pointeurs a, b, et c !
 */
void trier(int *a, int *b, int *c) {
    if(*a > *b)
        echanger(a,b);
    if(*b > *c)
        echanger(b,c);
    if(*a > *b)
        echanger(a,b);
}
