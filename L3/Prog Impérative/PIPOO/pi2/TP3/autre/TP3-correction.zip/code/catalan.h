#ifndef CATALAN_H
#define CATALAN_H

#include "fonctions.h"

long int catalan(int);

#endif
