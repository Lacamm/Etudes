#include "fonctions.h"

int main() {

    printf("%ld\n",coefficient(12,6));
    return EXIT_SUCCESS;
}
