#ifndef FONCTIONS_H
#define FONCTIONS_H

#include <stdlib.h>
#include <stdio.h>

long int factorielle(int);
long int coefficient(int, int);

#endif
