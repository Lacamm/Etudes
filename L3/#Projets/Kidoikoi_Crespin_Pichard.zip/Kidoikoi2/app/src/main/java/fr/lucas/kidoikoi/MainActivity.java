package fr.lucas.kidoikoi;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import fr.lucas.kidoikoi.BD.KidoikoiBaseHelper;
import fr.lucas.kidoikoi.Model.GroupeDepense;
import fr.lucas.kidoikoi.Tools.MyAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private LinearLayoutManager linearLayoutManager;
    private MyAdapter myAdapter;
    private Parcelable stateApp;

    private GroupeDepense monGroupe;

    private KidoikoiBaseHelper db;

//  Les request code pour les start activity on result
    public static final int NEW_UTILISATEUR_ACTIVITY_REQUEST_CODE = 1;
    public static final int NEW_DEP_ACTIVITY_REQUEST_CODE = 2;
    private static final int CHG_MDP_ACTIVITY_REQUEST_CODE = 3;

//  On stocke l'id de l'utilisateur connecté et la différence entre un guest et un utilisateur
//  connecté dans un booléen
    public int idUser;
    public boolean estConnecte = false;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_connexion);

        db = new KidoikoiBaseHelper(this);

        EditText identifiant_co = findViewById(R.id.identifiant_connexion);
        EditText mdp_co = findViewById(R.id.mdp_connexion);

        Button connexion = findViewById(R.id.connect);
        Button createAccount = findViewById(R.id.createaccount);
        Button guest = findViewById(R.id.guest);

//      gestion de la connexion, si mdp erroné ou utilisateur inexistant, on reste sur la page et
//      on affiche un message d'erreur, sinon on se connecte et on arrive sur le menu principal
        connexion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String identifiant = identifiant_co.getText().toString();
                String mdp = mdp_co.getText().toString();
                Cursor uti = db.getUtilisateur(identifiant);
                if (uti.getCount()==0){
                    Toast.makeText(view.getContext(),R.string.mauvais_identifiant,Toast.LENGTH_LONG);
                }
                else {
                    uti.moveToFirst();
                    if (uti.getString(4).equals(mdp)) {
                        mainAct(view,uti.getInt(0));
                    }
                    else{
                        Toast.makeText(view.getContext(),R.string.mauvais_mdp,Toast.LENGTH_LONG);
                        mdp_co.setText(null);
                    }
                }
            }
        });

//      pour la création d'un compte, on envoie dans la méthode creerCompte
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                creerCompte(view);
            }
        });

//      pour la connexion en tant que guest, on va directement sur la page principale
        guest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainAct(view, 0);
            }
        });

    }

    public void creerCompte(View view){

        setContentView(R.layout.activity_createaccount);

        Button nvCompte = findViewById(R.id.nvCompte);
        nvCompte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //On recupere sous forme editTexte les champs de saisie
                EditText getusername = findViewById(R.id.username);
                EditText getemail = findViewById(R.id.email);
                EditText getphone = findViewById(R.id.phone);
                EditText getpassword = findViewById(R.id.password);

                // On les transforme en String
                String userTexte = getusername.getText().toString().trim();
                String emailTexte = getemail.getText().toString();
                String phoneTexte = getphone.getText().toString();
                String passwordTexte = getpassword.getText().toString();

                //Ajout dans la bd
                boolean isInserted = db.insertData(userTexte,emailTexte,phoneTexte,passwordTexte);

                //si l'ajout est correct, on affiche les infos du nouveau compte, puis on va sur la
                // page principale, sinon on vide les champs de saisi et on reste sur la page
                if(isInserted==true){

                    Cursor res = db.getData();
                    StringBuffer buffer = new StringBuffer();
                    res.moveToLast();
                    buffer.append("id : "+res.getString(0)+"\n");
                    buffer.append("user : "+res.getString(1)+"\n");
                    buffer.append("email : "+res.getString(2)+"\n");
                    buffer.append("phone : "+res.getString(3)+"\n");
                    buffer.append("password : "+res.getString(4)+"\n\n");
                    Toast.makeText(view.getContext(),buffer, Toast.LENGTH_LONG).show();
                    mainAct(view, Integer.parseInt(res.getString(0)));
                }
                else{
                    Toast.makeText(view.getContext(),R.string.pb_crea_compte, Toast.LENGTH_LONG).show();
                    //remettre a null les champs de saisies
                    getusername.setText(null);
                    getemail.setText(null);
                    getphone.setText(null);
                    getpassword.setText(null);
                }
            }
        });

    }

//  page principale, on assigne les valeurs id et estConnecte, puis on créer un nouveau groupe
    public void mainAct(View view, int id){
        setContentView(R.layout.activity_main);

        this.idUser = id;

        if (id!=0) {
            this.estConnecte = true;
        }

        this.monGroupe = new GroupeDepense();

//      on créer et assigne les recyclerview et adapter pour afficher le groupe
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        myAdapter = new MyAdapter(this);
        myAdapter.setGroupe(monGroupe);
        recyclerView.setAdapter(myAdapter);
    }

//  on lance l'activié adduser
    public void addUtilisateur(View view) {
        startActivityForResult(new Intent(this, ActivityAddUser.class), NEW_UTILISATEUR_ACTIVITY_REQUEST_CODE);
    }

//  on lance l'activité adddepense
    public void addDepense(View view) {
        startActivityForResult(new Intent(this, ActivityAddDepense.class), NEW_DEP_ACTIVITY_REQUEST_CODE);
    }

//  pas utilisé, méthode pour créer un groupe de base et ajouter un utilisateur
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void creerGroupe(){
        db.insertData("Florent","","","oui");
        monGroupe.ajouterParticipant("Luca(");
        monGroupe.ajouterParticipant("Florent");
        monGroupe.ajouterDepense("Luca(", 20.0F);
    }

//  gestion des différents retours depuis les activités
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onActivityResult(int requestcode, int resultcode, Intent intent) {

        super.onActivityResult(requestcode, resultcode, intent);

//      pour un nouveau participant, on l'ajoute au groupe et on notifie l'adaptateur qui s'occupe
//      de l'affichage du groupe sur la page principale que des infos ont changees
        if(requestcode == NEW_UTILISATEUR_ACTIVITY_REQUEST_CODE){
            if(resultcode == Activity.RESULT_OK){
                monGroupe.ajouterParticipant(intent.getStringExtra("participant"));
                myAdapter.notifyDataSetChanged();
            }else{
                Toast.makeText(this,R.string.errUti, Toast.LENGTH_LONG).show();
            }
        }
//      pour une nouvelle depense, on l'ajoute au groupe et on notifie l'adaptateur qui s'occupe
//      de l'affichage du groupe sur la page principale que des infos ont changees
        else if (requestcode == NEW_DEP_ACTIVITY_REQUEST_CODE){
            if (resultcode == Activity.RESULT_OK){
                if (monGroupe.ajouterDepense(intent.getStringExtra("depParti"),intent.getFloatExtra("depVal", 100))){
                    Toast.makeText(this, R.string.dep_ajoutee, Toast.LENGTH_LONG).show();
                    myAdapter.notifyDataSetChanged();
                }
                else{
                    Toast.makeText(this, R.string.pb_ajout_dep, Toast.LENGTH_LONG).show();
                }
            }else{
                Toast.makeText(this,R.string.errDep, Toast.LENGTH_LONG).show();
            }
        }
//        pour une modification de mot de passe, on appelle la methode de la bd pour remplacer l'ancien
        else if (requestcode == CHG_MDP_ACTIVITY_REQUEST_CODE) {
            if (resultcode == Activity.RESULT_OK){
                db.modifierMDP(idUser,intent.getStringExtra("nvmdp"));
                Toast.makeText(this,R.string.mdp_change, Toast.LENGTH_LONG).show();
            }
        }
    }


//    on a essayer ces methodes pour enregistrer un groupe mais on a pas reussi
//    protected void onSaveInstanceState(Bundle state) {
//        super.onSaveInstanceState(state);
//        if (estConnecte) {
//            stateApp = linearLayoutManager.onSaveInstanceState();
//            state.putParcelable("infos", stateApp);
//        }
//    }
//
//    protected void onRestoreInstanceState(Bundle state){
//        super.onRestoreInstanceState(state);
//        if(state != null){
//            stateApp = state.getParcelable("infos");
//        }
//    }

//  afficher ou cacher un groupe
    public void afficherUtilisateurs(View view) {
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        if(recyclerView.getVisibility() == View.VISIBLE){
            recyclerView.setVisibility(View.GONE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

//  creation du menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

//  gestion des evenements lors du clic sur les menus
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

//      on envoie sur l'activite settigns et on gere le resultat dans une methode vue plus haut
        if (id == R.id.action_settings) {
            Intent i = new Intent(this, ActivitySettings.class);
            i.putExtra("estConnecte",estConnecte);
            i.putExtra("id",this.idUser);
            startActivityForResult(i, CHG_MDP_ACTIVITY_REQUEST_CODE);
            return true;
        }
//      on affiche tous les utilisateurs
        else if (id == R.id.action_liste_comptes){
            Cursor res = db.getData();
            StringBuffer buffer = new StringBuffer();
            while (res.moveToNext()) {
                buffer.append("id : " + res.getString(0) + "\n");
                buffer.append("user : " + res.getString(1) + "\n");
                buffer.append("email : " + res.getString(2) + "\n");
                buffer.append("phone : " + res.getString(3) + "\n");
                buffer.append("password : " + res.getString(4) + "\n\n");
            }
            Toast.makeText(this,buffer, Toast.LENGTH_LONG).show();
            return true;
        }
//      on appelle l'activite pour voir l'historique des depenses
        else if (id == R.id.action_historique && monGroupe!=null){
            Intent i = new Intent(this, ActivityHistoriqueDepense.class);
            i.putStringArrayListExtra("histoDep", (ArrayList<String>) monGroupe.getHistorique());
            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}