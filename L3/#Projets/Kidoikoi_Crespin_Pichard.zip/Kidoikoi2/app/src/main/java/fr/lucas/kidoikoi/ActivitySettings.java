package fr.lucas.kidoikoi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;



public class ActivitySettings extends AppCompatActivity {

    String nvmdp = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        boolean connecte = this.getIntent().getBooleanExtra("estConnecte",false);
        // on rend le bouton changer mdp visible que si un utilisateur est connecte
        Button bouton = findViewById(R.id.changePswd);
        if (connecte == false){
            bouton.setVisibility(View.GONE);
        }
        bouton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                changerMDP(view);
            }
        });
    }

//  mode nuit ou mode jour
    public void modeNuit(View view){
        int mode_act = AppCompatDelegate.getDefaultNightMode();
        if (mode_act == 1) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }
        else{
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    };

//  on affiche le layout de modification de mdp, on recupere le nouveau mot de passe et on revnoie
//  sur main actiity avec le nouveau mot de passe dans l'intent
    public void changerMDP(View view){
        setContentView(R.layout.activity_newpswd);
        EditText mdp = findViewById(R.id.password);
        Button chg_mdp = findViewById(R.id.chg_mdp);
        chg_mdp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (! mdp.getText().toString().isEmpty()){
                    nvmdp = mdp.getText().toString();
                    finish();
                }
            }
        });
    };

    @Override
    public void finish(){
        Intent intent = new Intent();
        intent.putExtra("nvmdp",nvmdp);
        setResult(Activity.RESULT_OK, intent);
        super.finish();
    }

}