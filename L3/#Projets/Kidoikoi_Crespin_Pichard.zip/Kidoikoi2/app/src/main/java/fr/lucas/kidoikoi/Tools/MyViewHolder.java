package fr.lucas.kidoikoi.Tools;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.Map;

import fr.lucas.kidoikoi.Model.GroupeDepense;
import fr.lucas.kidoikoi.R;

public class MyViewHolder {
    public static class MyViewHoolder extends RecyclerView.ViewHolder {

        private TextView tvNomGrp;
        private TextView tvDette;

        public MyViewHoolder(View intenView) {
            super(intenView);
            tvNomGrp = intenView.findViewById(R.id.tvNomCells);
            tvDette = intenView.findViewById(R.id.tvDette);
        }

//      on a un couple de valeur string float en parametre qui represente un participant et une
//      valeur de depense. on affiche ces deux valeurs dans les text view correspondantes de la cellule
        public void display(Map.Entry<String, Float> couple){

            tvNomGrp.setText(couple.getKey());
            tvDette.setText(couple.getValue().toString());
        }
    }
}
