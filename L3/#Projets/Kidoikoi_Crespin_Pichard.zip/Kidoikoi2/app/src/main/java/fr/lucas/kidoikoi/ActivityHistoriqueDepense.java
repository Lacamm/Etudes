package fr.lucas.kidoikoi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import fr.lucas.kidoikoi.Tools.AdapterHistorique;

public class ActivityHistoriqueDepense extends AppCompatActivity {

    private LinearLayoutManager linearLayoutManagerHistorique;
    private AdapterHistorique adapterHistorique;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historique_depense);

//      on creer la recycler view et on y ajoute l'historique des depenses

        RecyclerView recyclerViewHistorique = findViewById(R.id.recyclerview_historique);
        linearLayoutManagerHistorique = new LinearLayoutManager(this);
        recyclerViewHistorique.setLayoutManager(linearLayoutManagerHistorique);
        adapterHistorique = new AdapterHistorique(this);
        recyclerViewHistorique.setAdapter(adapterHistorique);

        adapterHistorique.setListeDepense(this.getIntent().getStringArrayListExtra("histoDep"));
    }

    @Override
    public void finish(){
        super.finish();
    }
}