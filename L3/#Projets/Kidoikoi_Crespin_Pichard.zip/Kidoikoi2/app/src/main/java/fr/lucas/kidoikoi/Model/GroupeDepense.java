package fr.lucas.kidoikoi.Model;

import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class GroupeDepense{

//  liste id pour les ids des utilisateurs avec un compte, pas le temps de l'implementer
    private List<Integer> listeId;
//  un groupe = un dictionnaire Participant : Valeur due
    private Map<String,Float> groupe = new HashMap<>();
//  historique des depenses, string = participant valeur depensee
    private List<String> historique = new ArrayList<>();

//  si l'utilisateur exixte dans le groupe, on soustraie sa depense divisee par le nbr de participants
//  a sa valeur totale, et on ajoute a tous les autres participants la meme valeur
//  on ajoute aussi la depense a l'historique
    @RequiresApi(api = Build.VERSION_CODES.N)
    public boolean ajouterDepense(String payeur, Float depense){

        Float valeur = depense/groupe.size();

        if (groupe.containsKey(payeur)){
            for (String participant : groupe.keySet()) {
                if (participant.equals(payeur)){
                    groupe.replace(payeur, groupe.get(payeur) - valeur);
                }
                else{
                    groupe.replace(participant, groupe.get(participant) + valeur);
                }
            }
            historique.add(payeur + depense);
            return true;

        }
        else{
            return false;
        }
    }

//  on ajoute le participant au groupe si il n'est pas complet, 10 participants max
    public boolean ajouterParticipant( String participant){
        if (groupe.size() < 10){
            groupe.put(participant, (float) 0);
            return true;
        }
        return false;
    }

    public Set<String> getParticipants(){
        return groupe.keySet();
    }

    public Map<String, Float> getGroupe() { return this.groupe; }

    public List<String> getHistorique(){ return this.historique; }

}
