package fr.lucas.kidoikoi;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ActivityAddUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adduser);

        final Button button = findViewById(R.id.valUti);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
    }

//  on recupere la valeur du nom de l'utilisateur et si elle est non vide, on renvoie
//  sur main activity avec ce nouveau participant en intent
    @Override
    public void finish(){
        EditText nom = findViewById(R.id.edtNomUtilisateur);
        Intent intent = new Intent();
        if(! nom.getText().toString().isEmpty()){
            intent.putExtra("participant", nom.getText().toString());
            setResult(Activity.RESULT_OK, intent);
        } else{
            setResult(Activity.RESULT_CANCELED, intent);
        }

        super.finish();
    }

}