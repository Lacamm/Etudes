package fr.lucas.kidoikoi.Tools;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import fr.lucas.kidoikoi.Model.GroupeDepense;
import fr.lucas.kidoikoi.R;

import java.util.List;

public class AdapterHistorique extends RecyclerView.Adapter<MyViewHolder2.MyViewHoolder>{

    private List<String> historique;

    private final LayoutInflater mInflater;

    public AdapterHistorique(Context context) { mInflater = LayoutInflater.from(context); }

    @NonNull
    @Override
    // crée des nouvelles vues pour recyclerView
    public MyViewHolder2.MyViewHoolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.cells,parent, false);
        MyViewHolder2.MyViewHoolder myViewHoolder = new MyViewHolder2.MyViewHoolder(view);
        return myViewHoolder;
    }

    @Override
    // remplace contenu d'une vue
    public void onBindViewHolder(@NonNull MyViewHolder2.MyViewHoolder holder, int position) {
        String depense = historique.get(position);
        holder.display(depense);
    }

    //nb elem à afficher dans recyclerView
    @Override
    public int getItemCount() {
        if (historique != null)
            return historique.size();
        else return 0;
    }

    public void setListeDepense(List<String> historique) {
        this.historique = historique;
        notifyDataSetChanged();
    }
}