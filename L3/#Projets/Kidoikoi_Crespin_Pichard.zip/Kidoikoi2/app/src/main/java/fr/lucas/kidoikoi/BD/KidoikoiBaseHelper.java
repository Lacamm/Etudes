package fr.lucas.kidoikoi.BD;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class KidoikoiBaseHelper extends SQLiteOpenHelper {

    private Context context;
    private static final int BASE_VERSION = 1;
    private static final String BASE_NOM = "BDKIDOIKOI";
    private static final String TABLE_NOM = "Account";
    public static final String COLONNE_ID = "id";
    public static final String COLONNE_USERNAME = "username";
    public static final String COLONNE_EMAIL="email";
    public static final String COLONNE_PHONE = "phone";
    public static final String COLONNE_PASSWORD="password";
    private KidoikoiBaseHelper db;
    private SQLiteDatabase maBaseDonnees;

    String queryCreate = " CREATE TABLE " + TABLE_NOM +
            " (" + COLONNE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLONNE_USERNAME + " TEXT, "
            + COLONNE_EMAIL + " TEXT, "
            + COLONNE_PHONE + " TEXT, "
            + COLONNE_PASSWORD + " TEXT);";

    String querydrop = " drop table " + TABLE_NOM + ";";

    public KidoikoiBaseHelper(Context context) {
        super(context, BASE_NOM, null, BASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(queryCreate);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int ancienneVersion, int newVersion) {

        Log.w(KidoikoiBaseHelper.class.getName(),
                "Upgrading database from version " + ancienneVersion + " to "
                        + newVersion + ", which will destroy all old data");

        db.execSQL(querydrop);//supprime l'ancienne table
        onCreate(db);        //on creer une nouvelle bd
    }

//  on insere un utilisateur a la bd
    public Boolean insertData(String username, String email, String phone, String pswd){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(COLONNE_USERNAME, username);
        contentValues.put(COLONNE_EMAIL, email);
        contentValues.put(COLONNE_PHONE, phone);
        contentValues.put(COLONNE_PASSWORD, pswd);
        long result = db.insert(TABLE_NOM, null, contentValues);
        if (result == -1) return false;
        else{
            // Log.d("test", "insertData: inseré");
            return true;
        }
    }

    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * from "+ TABLE_NOM +";", null);
    }

//  on renvoie l'id d'un utilisateur en le cherchant grace a son pseudo
    public String getIdUtilisateur(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = getUtilisateur(username);
        if (res.getCount()==0){
            return "-1";
        }
        else {
            res.moveToFirst();
            return res.getString(0);
        }
    }

//  on renvoie un curseur qui pointe vers un utilisateur en le cherchant avec son username
    public Cursor getUtilisateur(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("Select * from " + TABLE_NOM + " where " + COLONNE_USERNAME + "=\"" + username + "\";", null);
        return res;
    }

//  on renvoie un curseur qui pointe vers un utilisateur en le cherchant avec son id
    public Cursor getUtilisateurById(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("Select * from " + TABLE_NOM + " where " + COLONNE_ID + "=\"" + id + "\";", null);
        return res;
    }

    public void supprimerBD(){
        this.getWritableDatabase().execSQL(querydrop);
    }

//  on modifie le mot de passe d'un utilisateur en le cherchant avec son id puis en utilisant
//  la methode db.update
    public void modifierMDP(int id, String mdp){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor uti = getUtilisateurById(id);
        uti.moveToFirst();
        ContentValues res = new ContentValues();
        res.put(COLONNE_ID,uti.getInt(0));
        res.put(COLONNE_USERNAME,uti.getString(1));
        res.put(COLONNE_EMAIL,uti.getString(2));
        res.put(COLONNE_PHONE,uti.getString(3));
        res.put(COLONNE_PASSWORD, mdp);
        db.update(TABLE_NOM,res,null,null);
    }

}
