package fr.lucas.kidoikoi.Tools;

import android.content.Context;
import android.os.Build;
import android.os.Parcelable;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.RecyclerView;

import fr.lucas.kidoikoi.Model.GroupeDepense;
import fr.lucas.kidoikoi.R;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;


public class MyAdapter extends RecyclerView.Adapter<MyViewHolder.MyViewHoolder>{

    private GroupeDepense groupe;

    private final LayoutInflater mInflater;

    public MyAdapter (Context context) { mInflater = LayoutInflater.from(context); }

    @NonNull
    @Override
    // crée des nouvelles vues pour recyclerView
    public MyViewHolder.MyViewHoolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.cells,parent, false);
        MyViewHolder.MyViewHoolder myViewHoolder = new MyViewHolder.MyViewHoolder(view);
        return myViewHoolder;
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    // remplace contenu d'une vue
    public void onBindViewHolder(@NonNull MyViewHolder.MyViewHoolder holder, int position) {
        List<Map.Entry<String, Float>> tmp = new ArrayList<>();
        groupe.getGroupe().entrySet().forEach(p -> tmp.add(p));
        Map.Entry<String, Float> participant = tmp.get(position);
        holder.display(participant);
    }

    //nb elem à afficher dans recyclerVieww
    @Override
    public int getItemCount() {
        if (groupe.getParticipants() != null)
            return groupe.getParticipants().size();
        else return 0;
    }

    public void setGroupe(GroupeDepense groupe) {
        this.groupe = groupe;
        notifyDataSetChanged();
    }
}