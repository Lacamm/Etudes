package fr.lucas.kidoikoi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityAddDepense extends AppCompatActivity {

    EditText val;
    EditText nom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adddepense);

        val = findViewById(R.id.edtValDepense);
        nom = findViewById(R.id.edtUtiDep);

        final Button button = findViewById(R.id.valDep);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
    }

//  on recupere la valeur du nom du participant et la valeur de la depense et si elles sont non vide,
//  on renvoie sur main activity avec ce nouveau participant et la valeur en intent

    @Override
    public void finish(){

        Intent intent = new Intent();
        if(! nom.getText().toString().isEmpty() && ! val.getText().toString().isEmpty()){
            intent.putExtra("depVal", Float.valueOf(val.getText().toString()));
            intent.putExtra("depParti",nom.getText().toString());
            setResult(Activity.RESULT_OK, intent);
        } else{
            setResult(Activity.RESULT_CANCELED, intent);
        }
        super.finish();
    }
}