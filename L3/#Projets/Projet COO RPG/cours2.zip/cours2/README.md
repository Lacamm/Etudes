## Cours2

Ce projet reprend le code vue dans les 
cours 1 et 2 et une toute petite partie du 3e cours. Cependant, il contient 
quelques améliorations :
1. *Dans templates (fichiers twig) :*
    - ajout d'un répertoire *layer* contenant 
  des composants élémentaires utiliser dans les pages principales.
      
2. *Style Bootstrap avec webpack encore*
3. *Style Bootstrap pour les formulaires*
    - dans config->parkages->twig, ajout de la ligne 
      
```
    form_themes:['bootstrap_5_layout.html.twig']
```
4. *Ajout des attributs createdAt et updatedAt*
    - voir dans Article.php, la fonction updateTimestamps 
      et surtout l'annotation
```  
    #[ORM\PreUpdate,ORM\PrePersist]
```

    ainsi que : ORM\HasLifecycleCallbacks en entête de la classe.

## Installation

Dans votre conteneur `docker` et dans le répertoire du projet, faire

```
• symfony composer install
• symfony console doctrine:migrations:migrate 
• symfony console doctrine:fixture:load
• npm install
• npm run dev
```