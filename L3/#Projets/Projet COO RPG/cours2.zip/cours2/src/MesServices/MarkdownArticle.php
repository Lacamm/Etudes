<?php


namespace App\MesServices;


use App\Entity\Article;
use cebe\markdown\Markdown;

class MarkdownArticle
{
    protected $markdown;
    public function __construct(Markdown $markdown)
    {
        $this->markdown = $markdown;
    }

    public function parse(Article $article) : Article
    {
        $parseArticle = $article;
        $parseArticle ->setDescription($this->markdown->parse($article->getDescription()));
        return $parseArticle;
    }

    public function parseArray(array $articles) : array
    {
        $parsedArticles = [];
        foreach ($articles  as $article) {
            $parseArticle = $article;
            $parseArticle ->setDescription($this->markdown->parse($article->getDescription()));
            $parsedArticles[] = $parseArticle;
        }
        return $parsedArticles;
    }
}