package modele.exceptions;

public class NonSupporteeException extends Exception {
}
