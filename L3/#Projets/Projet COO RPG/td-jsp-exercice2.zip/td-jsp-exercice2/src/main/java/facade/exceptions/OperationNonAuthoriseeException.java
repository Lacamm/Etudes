package facade.exceptions;

public class OperationNonAuthoriseeException extends Exception {
    public OperationNonAuthoriseeException(String s) {
        super(s);
    }
}
