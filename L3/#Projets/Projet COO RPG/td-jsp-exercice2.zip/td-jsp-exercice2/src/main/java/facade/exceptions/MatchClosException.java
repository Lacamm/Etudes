package facade.exceptions;

public class MatchClosException extends Exception {
}
