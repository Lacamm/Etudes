package facade.exceptions;

public class InformationsSaisiesIncoherentesException extends Exception {
}
