package facade.exceptions;

public class MontantNegatifOuNulException extends Exception {
}
