package modele;

public class DejaJoueException extends Exception {
}
