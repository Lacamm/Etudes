package modele;

import java.util.*;

public class FacadeShiffumiImpl implements FacadeShiffumi {

    private Map<String, Partie> listePartiesEnAttente;
    private Map<String, Partie> listePartiesEnCours;

    public FacadeShiffumiImpl() {

        this.listePartiesEnAttente = new HashMap<>();
        this.listePartiesEnCours = new HashMap<>();
    }

    @Override
    public String creerPartie(String createur, String invite) throws PseudosIncorrectsException {
        if (Objects.isNull(createur) || createur.isBlank() || Objects.isNull(invite) || invite.isBlank()) {
            throw new PseudosIncorrectsException();
        }

        Partie partie = new Partie(UUID.randomUUID().toString(),createur,invite);
        listePartiesEnAttente.put(partie.getIdentifiant(),partie);

        return partie.getIdentifiant();
    }


    @Override
    public void rejoindrePartie(String pseudoInvite, String identifiantPartie)
            throws PartieInexistanteException, PseudoInconnuDansLaPartieException {

        Partie partie = this.listePartiesEnAttente.get(identifiantPartie);

        if (Objects.isNull(partie)) {
            throw new PartieInexistanteException();
        }

        partie.checkJoueur(pseudoInvite);

        this.listePartiesEnAttente.remove(partie);
        this.listePartiesEnCours.put(partie.getIdentifiant(),partie);

    }

    @Override
    public void jouer(String pseudo, String identifiantPartie, Coups coup) throws PartieInexistanteException, PseudoInconnuDansLaPartieException, DejaJoueException, PartieTermineeException {

        Partie partie = this.listePartiesEnCours.get(identifiantPartie);

        if (Objects.isNull(partie)) {
            throw new PartieInexistanteException();
        }

        partie.checkJoueur(pseudo);

        partie.jouer(pseudo,coup);



    }

    @Override
    public void abandonner(String pseudo, String identifiantPartie) throws PartieInexistanteException, PseudoInconnuDansLaPartieException {

        Partie partie = this.listePartiesEnCours.get(identifiantPartie);

        if (Objects.isNull(partie)) {
            throw new PartieInexistanteException();
        }

        partie.checkJoueur(pseudo);

        partie.abandonner(pseudo);

    }

    @Override
    public ScorePartie getScore(String identifiantPartie) throws PartieInexistanteException {

        Partie partie = this.listePartiesEnCours.get(identifiantPartie);

        if (Objects.isNull(partie)) {
            throw new PartieInexistanteException();
        }

        return partie.getScore();
    }

    @Override
    public List<Coups> getCoupsPossibles() {
        return Arrays.asList(Coups.values());
    }

    @Override
    public boolean isPartieCommencee(String idPartie) {
        if (this.listePartiesEnCours.containsKey(idPartie))
            return true;

        return false;
    }

    @Override
    public boolean isPartieTerminee(String idPartie) throws PartieInexistanteException {
        ScorePartie scorePartie = this.getScore(idPartie);
        return scorePartie.isPartieTerminee();
    }
}
