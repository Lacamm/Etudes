package modele;

public class PartieNonTermineeException extends Exception {
}
