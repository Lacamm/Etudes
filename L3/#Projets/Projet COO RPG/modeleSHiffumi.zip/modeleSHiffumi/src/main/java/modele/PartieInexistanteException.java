package modele;

public class PartieInexistanteException extends Exception {
}
