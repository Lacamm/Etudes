package modele;

public class PseudoInconnuDansLaPartieException extends Exception {
}
