package modele;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class ScorePartie {
    public int getNbRound() {
        return nbRound;
    }

    private final static int NB_ROUND = 3;
    private String[] joueurs;
    private Map<String,Integer> score;
    private String gagnant;
    private boolean partieTerminee;

    public String[] getJoueurs() {
        return joueurs;
    }

    private int nbRound;

    public Map<String, Integer> getScore() {
        return score;
    }

    public ScorePartie(String[] joueurs) {
        this.joueurs = joueurs;
        this.score = new HashMap<>();
        for (String j : joueurs) {
            this.score.put(j,0);
        }
        this.partieTerminee  = false;
        this.nbRound = 0;
    }

    public boolean isPartieTerminee() {
        return partieTerminee;
    }

    public String getGagnant() throws PartieNonTermineeException, MatchNulException {
        if (isPartieTerminee()) {
            if (Objects.isNull(gagnant)) {
                throw new MatchNulException();
            }
            return gagnant;
        }
        else throw new PartieNonTermineeException();
    }


    private void checkEtatPartie() {

        if (NB_ROUND == this.nbRound) {

            if (this.score.get(joueurs[0]) > this.score.get(joueurs[1])) {
                this.gagnant = joueurs[0];
            }

            if (this.score.get(joueurs[0]) < this.score.get(joueurs[1])) {
                this.gagnant = joueurs[1];
            }

            this.partieTerminee = true;
        }
        else {

            if (this.score.get(joueurs[0]) == 2) {
                this.partieTerminee = true;
                this.gagnant = joueurs[0];
            }



            if (this.score.get(joueurs[1]) == 2) {
                this.partieTerminee = true;
                this.gagnant = joueurs[1];
            }
        }

    }

    void update(String j1, FacadeShiffumi.Coups chx1, String j2, FacadeShiffumi.Coups chx2) throws PartieTermineeException {

        if (this.nbRound < NB_ROUND && !this.partieTerminee) {
            switch (chx1) {
                case PIERRE -> {
                    if (chx2 == FacadeShiffumi.Coups.CISEAUX) {
                        score.put(j1, score.get(j1) + 1);
                    }
                    if (chx2 == FacadeShiffumi.Coups.FEUILLE) {
                        score.put(j2, score.get(j2) + 1);
                    }
                    break;
                }

                case CISEAUX -> {
                    if (chx2 == FacadeShiffumi.Coups.FEUILLE) {
                        score.put(j1, score.get(j1) + 1);
                    }
                    if (chx2 == FacadeShiffumi.Coups.PIERRE) {
                        score.put(j2, score.get(j2) + 1);
                    }
                    break;
                }

                case FEUILLE -> {
                    if (chx2 == FacadeShiffumi.Coups.PIERRE) {
                        score.put(j1, score.get(j1) + 1);
                    }
                    if (chx2 == FacadeShiffumi.Coups.CISEAUX) {
                        score.put(j2, score.get(j2) + 1);
                    }
                    break;
                }
            }

            nbRound++;
            checkEtatPartie();
        }
        else {
            throw new PartieTermineeException();
        }
    }

    public void abandon(String pseudo) {
        this.partieTerminee = true;
        this.gagnant = this.joueurs[0].equals(pseudo)?this.joueurs[1]:this.joueurs[0];
    }
}
