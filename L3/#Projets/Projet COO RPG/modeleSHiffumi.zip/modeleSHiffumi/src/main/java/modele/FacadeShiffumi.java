package modele;


import java.util.List;

public interface FacadeShiffumi {

    enum Coups {PIERRE,FEUILLE,CISEAUX};


    /**
     * Permet de créer une partie
     * @param createur : pseudo du créateur
     * @param invite : pseudo de l'invité
     * @return ; chaîne aléatoire correspondant à l'identifiant de la partie
     */

    String creerPartie(String createur, String invite) throws PseudosIncorrectsException;


    /**
     * Permet de rejoindre une partie
     * @param pseudoInvite : pseudo de l'invité voulant rejoindre la partie
     * @param identifiantPartie : identifiant de la partie à rejoindre
     */
    void rejoindrePartie(String pseudoInvite, String identifiantPartie) throws PartieInexistanteException, PseudoInconnuDansLaPartieException;


    /**
     * Permet de jouer un coup
     * @param pseudo : pseudo jouant
     * @param identifiantPartie : identifiant de la partie concernée
     * @param coup : coup joué
     * @throws PartieInexistanteException
     * @throws PseudoInconnuDansLaPartieException
     * @throws DejaJoueException
     * @throws PartieTermineeException
     */

    void jouer(String pseudo, String identifiantPartie, Coups coup) throws PartieInexistanteException,
            PseudoInconnuDansLaPartieException, DejaJoueException, PartieTermineeException;


    /**
     *
     * @param pseudo : pseudo voulant abandonner
     * @param identifiantPartie : identifiant de la partie concernée
     * @throws PartieInexistanteException
     * @throws PseudoInconnuDansLaPartieException
     */
    void abandonner(String pseudo, String identifiantPartie) throws PartieInexistanteException,
            PseudoInconnuDansLaPartieException;


    /**
     * Permet de récupérer le score de la partie
     * @param identifiantPartie
     * @return
     * @throws PartieInexistanteException
     */

    ScorePartie getScore(String identifiantPartie)  throws PartieInexistanteException;


    /**
     * Permet de récupérer les coups possibles
     * @return
     */

    List<Coups> getCoupsPossibles();


    boolean isPartieCommencee(String idPartie);

    boolean isPartieTerminee(String idPartie) throws PartieInexistanteException;



}
