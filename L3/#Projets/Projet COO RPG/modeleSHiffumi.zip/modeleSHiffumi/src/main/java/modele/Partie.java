package modele;


import java.util.HashMap;
import java.util.Map;

public class Partie {

    private String identifiant;
    private String[] joueurs;
    private ScorePartie scorePartie;
    private Map<String,FacadeShiffumi.Coups> choix;


    public Partie(String identifiant, String joueur1, String joueur2){
        this.identifiant = identifiant;
        this.joueurs = new String[]{joueur1,joueur2};
        this.scorePartie = new ScorePartie(joueurs);
        this.choix = new HashMap<>();
    }

    public String getIdentifiant() {
        return identifiant;
    }

    public void checkJoueur(String pseudoInvite) throws PseudoInconnuDansLaPartieException {
        for (String j : joueurs) {
            if (j.equals(pseudoInvite)) {
                return;
            }
        }
        throw new PseudoInconnuDansLaPartieException();
    }

    public void jouer(String pseudo, FacadeShiffumi.Coups coup) throws DejaJoueException, PartieTermineeException {
        if (choix.containsKey(pseudo)) {
            throw new DejaJoueException();
        }
        choix.put(pseudo,coup);
        if (checkTousOntChoisi()){
            majScore();
            resetChoix();
        }

    }

    private void resetChoix() {
        this.choix.clear();
    }

    private void majScore() throws PartieTermineeException {
        this.scorePartie.update(joueurs[0],choix.get(joueurs[0]),joueurs[1],choix.get(joueurs[1]));
    }


    private boolean checkTousOntChoisi(){
        for (String j : joueurs) {
            if (!choix.containsKey(j)) {
                return false;
            }
        }
        return true;
    }
    public void abandonner(String pseudo) {

        this.scorePartie.abandon(pseudo);
    }

    public ScorePartie getScore() {
        return this.scorePartie;
    }


    public boolean partieTerminee() {
        return this.scorePartie.isPartieTerminee();
    }
}
