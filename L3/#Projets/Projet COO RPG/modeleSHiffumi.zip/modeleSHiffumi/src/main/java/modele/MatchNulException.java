package modele;

public class MatchNulException extends Exception {
}
