package modele;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TestFacadeShiffumiImpl {




    private FacadeShiffumiImpl facadeShiffumi;




    @Before
    public void initialisation(){
        this.facadeShiffumi = new FacadeShiffumiImpl();
    }


    @Test
    public void scenarioNormalJ1Wins() throws PseudosIncorrectsException, PseudoInconnuDansLaPartieException, PartieInexistanteException, DejaJoueException, PartieTermineeException, PartieNonTermineeException, MatchNulException {
        String j1 = "j1";
        String j2 = "j2";
        String id = this.facadeShiffumi.creerPartie(j1,j2);
        this.facadeShiffumi.rejoindrePartie(j2,id);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.CISEAUX);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.CISEAUX);

        Assert.assertTrue(this.facadeShiffumi.getScore(id).isPartieTerminee());
        Assert.assertEquals(this.facadeShiffumi.getScore(id).getGagnant(),j1);
    }


    @Test
    public void scenarioNormalJ2Wins() throws PseudosIncorrectsException, PseudoInconnuDansLaPartieException, PartieInexistanteException, DejaJoueException, PartieTermineeException, PartieNonTermineeException, MatchNulException {
        String j1 = "j1";
        String j2 = "j2";
        String id = this.facadeShiffumi.creerPartie(j1,j2);
        this.facadeShiffumi.rejoindrePartie(j2,id);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.CISEAUX);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.CISEAUX);

        Assert.assertTrue(this.facadeShiffumi.getScore(id).isPartieTerminee());
        Assert.assertEquals(this.facadeShiffumi.getScore(id).getGagnant(),j2);
    }

    @Test
    public void scenarioNormalJ1WinsIn3Rounds() throws PseudosIncorrectsException, PseudoInconnuDansLaPartieException, PartieInexistanteException, DejaJoueException, PartieTermineeException, PartieNonTermineeException, MatchNulException {
        String j1 = "j1";
        String j2 = "j2";
        String id = this.facadeShiffumi.creerPartie(j1,j2);
        this.facadeShiffumi.rejoindrePartie(j2,id);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.CISEAUX);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.CISEAUX);

        Assert.assertTrue(this.facadeShiffumi.getScore(id).isPartieTerminee());
        Assert.assertEquals(this.facadeShiffumi.getScore(id).getGagnant(),j1);
    }


    @Test
    public void scenarioNormalJ2WinsIn3Rounds() throws PseudosIncorrectsException, PseudoInconnuDansLaPartieException, PartieInexistanteException, DejaJoueException, PartieTermineeException, PartieNonTermineeException, MatchNulException {
        String j1 = "j1";
        String j2 = "j2";
        String id = this.facadeShiffumi.creerPartie(j1,j2);
        this.facadeShiffumi.rejoindrePartie(j2,id);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.CISEAUX);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.CISEAUX);

        Assert.assertTrue(this.facadeShiffumi.getScore(id).isPartieTerminee());
        Assert.assertEquals(this.facadeShiffumi.getScore(id).getGagnant(),j2);
    }



    @Test(expected = MatchNulException.class)
    public void noWinner() throws PseudosIncorrectsException, PseudoInconnuDansLaPartieException, PartieInexistanteException, DejaJoueException, PartieTermineeException, PartieNonTermineeException, MatchNulException {
        String j1 = "j1";
        String j2 = "j2";
        String id = this.facadeShiffumi.creerPartie(j1,j2);
        this.facadeShiffumi.rejoindrePartie(j2,id);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.PIERRE);

        Assert.assertTrue(this.facadeShiffumi.getScore(id).isPartieTerminee());
       this.facadeShiffumi.getScore(id).getGagnant();

    }



    @Test(expected = DejaJoueException.class)
    public void doubleChoix() throws PseudosIncorrectsException, PseudoInconnuDansLaPartieException, PartieInexistanteException, DejaJoueException, PartieTermineeException {
        String j1 = "j1";
        String j2 = "j2";
        String id = this.facadeShiffumi.creerPartie(j1,j2);
        this.facadeShiffumi.rejoindrePartie(j2,id);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j1,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);
        this.facadeShiffumi.jouer(j2,id, FacadeShiffumi.Coups.PIERRE);

    }


}
