<?php

namespace App\DataFixtures;

use App\Entity\Article;
use App\Entity\Category;
use App\Entity\User;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class ArticleFixtures extends Fixture
{
    private UserPasswordHasherInterface $passwordHasher;
    public function __construct(UserPasswordHasherInterface $passwordHasher) {
        $this->passwordHasher = $passwordHasher;
    }

    public function load(ObjectManager $manager): void
    {
        $user = new User();
        $user->setUsername('toto')
            ->setPassword($this->passwordHasher->hashPassword($user,'secret'));
        $manager->persist($user);

        $faker = \Faker\Factory::create("fr_FR");
        for($k=1; $k<5; $k++) {
            $category = new Category();
            $category->setName($faker->word);
            $manager->persist($category);
            for($i=1; $i<=4; $i++ ) {
                $article = new Article();
                $article->setTitle($faker->sentence)
                    ->setDescription(join("\n\n",$faker->paragraphs) )
                    ->setCategory($category)
                    ->setAuthor($user);
                $manager->persist($article);
            }
        }
        $manager->flush();    }
}
