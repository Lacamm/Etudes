## Cours2

Ce projet reprend le code du cours 3.
## Installation

Dans votre conteneur `docker` et dans le répertoire du projet, faire

```
• symfony composer install
• symfony console doctrine:migrations:migrate 
• symfony console doctrine:fixture:load
• npm install
• npm run dev
```

https://symfony.com/doc/current/reference/forms/types/entity.html